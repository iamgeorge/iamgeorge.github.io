-- -----------------------------------------------------
-- --------------- Solution for Q10 --------------------
-- -----------------------------------------------------
SELECT DEPARTMENT_ID, AVG(SALARY), COUNT(*)
FROM employees
GROUP BY department_id  having count(*) > 10