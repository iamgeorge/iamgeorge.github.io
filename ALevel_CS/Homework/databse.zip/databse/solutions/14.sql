-- -----------------------------------------------------
-- --------------- Solution for Q14 --------------------
-- -----------------------------------------------------
SELECT EMPLOYEE_ID,JOB_ID,departments.DEPARTMENT_ID, departments.DEPARTMENT_NAME
FROM employees
LEFT JOIN departments 
on employees.department_id = departments.department_id 
WHERE location_id = 1700