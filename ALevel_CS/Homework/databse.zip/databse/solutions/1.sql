-- -----------------------------------------------------
-- ---------------- Solution for Q1 --------------------
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Meta Data Settings: Leave These Unchanged
-- -----------------------------------------------------
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Drop Schema `as2`: Leave It Unchanged
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `as2`;

-- -----------------------------------------------------
-- Create Schema `as2`: Leave It Unchanged
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `as2` DEFAULT CHARACTER SET utf8;
USE `as2`;

-- -----------------------------------------------------
-- Create Table `regions` here
-- -----------------------------------------------------

CREATE TABLE `regions` (
  `region_id` int(5),
  `region_name` varchar(25) NOT NULL
);

-- -----------------------------------------------------
-- Create Table `countries` here
-- -----------------------------------------------------
CREATE TABLE `countries` (
  `country_id` char(2),
  `country_name` varchar(25) NOT NULL,
  `region_id` int(5) NOT NULL
);


-- -----------------------------------------------------
-- Create Table `locations` here
-- -----------------------------------------------------
CREATE TABLE `locations` (
  `location_id` int(4),
  `street_address` varchar(40),
  `postal_code` varchar(12),
  `city` varchar(30) NOT NULL,
  `state_province` varchar(25),
  `country_id` char(2) NOT NULL
);


-- -----------------------------------------------------
-- Create Table `jobs` here
-- -----------------------------------------------------
CREATE TABLE `jobs` (
  `job_id` char(10),
  `job_title` varchar(35) NOT NULL,
  `min_salary` int(6),
  `max_salary` int(6)
);


-- -----------------------------------------------------
-- Create Table `employees` here
-- -----------------------------------------------------
CREATE TABLE `employees` (
  `employee_id` int(6),
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(20),
  `hire_date` date NOT NULL,
  `job_id` char(10) NOT NULL,
  `salary` float(8,2),
  `commission_pct` float(2,2),
  `manager_id` int(6),
  `department_id` int(4)
);


-- -----------------------------------------------------
-- Create Table `departments` here
-- -----------------------------------------------------
CREATE TABLE `departments` (
  `department_id` int(4),
  `department_name` varchar(30) NOT NULL,
  `manager_id` int(6),
  `location_id` int(4)
);


-- -----------------------------------------------------
-- Create Table `job_history` here
-- -----------------------------------------------------
CREATE TABLE `job_history` (
  `employee_id` int(6),
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `job_id` char(10) NOT NULL,
  `department_id` int(4)
);

-- -----------------------------------------------------
-- Recover Meta Data: Leave These Unchanged
-- -----------------------------------------------------
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
