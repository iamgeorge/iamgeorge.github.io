-- -----------------------------------------------------
-- ---------------- Solution for Q2 --------------------
-- -----------------------------------------------------

SELECT first_name as "First Name", last_name as "Last Name" FROM employees;