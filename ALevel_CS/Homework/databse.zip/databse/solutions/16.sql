-- -----------------------------------------------------
-- --------------- Solution for Q16 --------------------
-- -----------------------------------------------------
SELECT departments.DEPARTMENT_ID,departments.DEPARTMENT_NAME,employees.FIRST_NAME 
FROM employees
INNER JOIN
departments 
on departments.manager_id = employees.employee_id  