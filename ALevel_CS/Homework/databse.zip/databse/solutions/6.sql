-- -----------------------------------------------------
-- ---------------- Solution for Q6 --------------------
-- -----------------------------------------------------
SELECT  EMPLOYEE_ID FROM employees where EMPLOYEE_ID = '200' OR EMPLOYEE_ID = '203' OR EMPLOYEE_ID = '204'