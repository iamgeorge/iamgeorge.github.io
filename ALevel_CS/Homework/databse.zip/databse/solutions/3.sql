-- -----------------------------------------------------
-- ---------------- Solution for Q3 --------------------
-- -----------------------------------------------------
SELECT employee_id as "EMPLOYEE_ID", salary as "SALARY" FROM employees ORDER BY salary ASC;