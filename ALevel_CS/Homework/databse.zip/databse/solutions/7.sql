-- -----------------------------------------------------
-- ---------------- Solution for Q7 --------------------
-- -----------------------------------------------------
SELECT EMPLOYEE_ID, PHONE_NUMBER FROM employees WHERE department_id = 20 OR department_id = 100 ORDER BY department_id DESC;