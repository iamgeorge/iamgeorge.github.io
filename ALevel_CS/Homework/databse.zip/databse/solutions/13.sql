-- -----------------------------------------------------
-- --------------- Solution for Q13 --------------------
-- -----------------------------------------------------
SELECT EMPLOYEE_ID, SALARY FROM employees WHERE SALARY = (SELECT SALARY FROM employees ORDER BY salary ASC LIMIT 5,1)