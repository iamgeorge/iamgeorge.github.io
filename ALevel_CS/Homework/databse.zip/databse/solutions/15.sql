-- -----------------------------------------------------
-- --------------- Solution for Q15 --------------------
-- -----------------------------------------------------



SELECT department_id as "Department Name", COUNT(*) as "Number of Employees" FROM (SELECT departments.department_id 
FROM employees
LEFT JOIN departments 
ON employees.department_id = departments.department_id) AS T
WHERE department_id IS NOT NULL
GROUP BY department_id