-- -----------------------------------------------------
-- --------------- Solution for Q11 --------------------
-- -----------------------------------------------------
SELECT FIRST_NAME,LAST_NAME
FROM employees
WHERE manager_id != 201 AND manager_id != 203 AND manager_id != 204 AND manager_id != 145 AND manager_id != 146 AND manager_id != 147 AND manager_id != 148 AND manager_id != 149   
