from checker import check
def test():
  assert check(6)