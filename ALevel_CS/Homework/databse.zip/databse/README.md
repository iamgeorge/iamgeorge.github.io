[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=9220085&assignment_repo_type=AssignmentRepo)
# CSC3170 Assignment 2 - Classroom Repo

<img alt="points bar" align="right" height="36" src="../../blob/badges/.github/badges/points-bar.svg" />

![GitHub Classroom Workflow](../../workflows/GitHub%20Classroom%20Workflow/badge.svg?branch=master)

This is a GitHub classroom repository for CUHK(SZ)-CSC3170-2022Fall-Assignment 2. The status of the autograding and the points you get are shown above. This is basically about fundamental Data Definition Language (DDL) and Data Manipulating Language (DML) in **MySQL**. We provide autograding codes in the repository, but you can also utilize them locally to test whether your implementation is okay. The details of the description for this assignment are shown in [assignment.md](assignment.md), and you should check that before starting your implementation. If you don't use the local testing but just use the autograding strategy of GitHub Action, you can omit the following sections (but it's helpful for efficiently checking the results). You can commit locally whenever you think you need to store some changes, and every time you think your implementation is okay (after some modification), you may push it to the remote repository, and the autograding script will start to work with the help of GitHub Action (you may need to refresh the webpage to see the results after the procedure is finished).

## Pre-requisition for local testing

You should ensure that `python` (>=3.6) is installed in your computer. You may use `conda` or other python virtual environment management software, but you need to activate your virtual environment before you start the following steps.

## Dependency installation for local testing

You can run the following commands for installing the dependency:

```bash
pip install pytest
pip install pymysql
pip install pandas
pip install openpyxl
```

You may add `sudo` before these command when the level of privilege is not high enough. In linux, it's suggested to use `sudo -H pip install pytest` for the first command as it will be a command line program that you are going to utilize.

## Execute the test for local testing

You can run the following commands for executing the test:

```bash
cd test
pytest test1.py
pytest
```

Here you run the first test first as it will create the database and schemas required in the following tests. If you don't implement it correctly, the successive tests will be problematic. Then, the `pytest` command will gather all the tests and run them. If you pass all tests locally, you should get full marks in the autograding procedure. Note that you need to alter the password of your local `root` user to `root`. You can execute the following script after you log in the MySQL server with `root` user:

```sql
ALTER USER 'root'@'localhost' IDENTIFIED BY 'root'
```
